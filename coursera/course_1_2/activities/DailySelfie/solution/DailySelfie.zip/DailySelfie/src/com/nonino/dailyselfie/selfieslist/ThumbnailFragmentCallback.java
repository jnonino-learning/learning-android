package com.nonino.dailyselfie.selfieslist;

public interface ThumbnailFragmentCallback {

	public void openFullImageFragment(String fullImagePath);
}
